//
//  ViewController.swift
//  UseSafariServicesToLoadWebpage29
//
//  Created by iMac on 17/08/22.
//

import UIKit
import SafariServices

class ViewController: UIViewController {

    @IBOutlet weak var BUttonGoToWeb: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func btnWebPageAction(_ sender: Any) {
        if let url = URL(string: "https://github.com"){
            let safariVC = SFSafariViewController(url: url)
            present(safariVC, animated: true, completion: nil)
        }
        
    }
    
    @IBAction func btnGoToWeb(_ sender: Any) {
        let wVC = self.storyboard?.instantiateViewController(withIdentifier: "wkWebViewController") as! wkWebViewController
        self.navigationController?.pushViewController(wVC, animated: true)
    }
    
    
}

