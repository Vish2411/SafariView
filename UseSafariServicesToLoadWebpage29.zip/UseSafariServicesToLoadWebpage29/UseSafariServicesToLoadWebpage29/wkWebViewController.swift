//
//  wkWebViewController.swift
//  UseSafariServicesToLoadWebpage29
//
//  Created by iMac on 17/08/22.
//

import UIKit
import WebKit


class wkWebViewController: UIViewController, WKNavigationDelegate, WKUIDelegate {

    @IBOutlet weak var wkWebView: WKWebView!
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        passViewDidLoad()
    }
    
    func passViewDidLoad(){
        
        wkWebView.navigationDelegate = self
        wkWebView.uiDelegate = self
        activityIndicator.hidesWhenStopped = true
        activityIndicator.style = .medium
        activityIndicator.color = .blue
     
        guard let url = URL(string: "https://github.com") else { return }
        let request = URLRequest(url: url)
        self.wkWebView.load(request)
    }
    
    func showActivityIndicator(show: Bool) {
            if show {
                activityIndicator.startAnimating()
            } else {
                activityIndicator.stopAnimating()
            }
        }
    
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
            showActivityIndicator(show: false)
        }

        func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) {
            showActivityIndicator(show: true)
        }

        func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
            showActivityIndicator(show: false)
        }
}
